export default function App() {
    return (
      <h1 className="bg-blue-500">Calculadora</h1>

    )
    
}


