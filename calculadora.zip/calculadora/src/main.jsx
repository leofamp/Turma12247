import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import Calculadora from './components/Calculadora.jsx'
import Counter from './components/Counter.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <Calculadora />    
  </StrictMode>,
)
